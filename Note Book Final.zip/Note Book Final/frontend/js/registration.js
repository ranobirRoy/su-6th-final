//============Ragistration system========================
const handleRegistration = async () => {
  const inputName = document.getElementById("inputName");
  const inputPassword = document.getElementById("inputPassword");
  const errorRegistration = document.getElementById("errorRegistration");

  const name = inputName.value;
  const password = inputPassword.value;
  if (!name || !password) {
    errorRegistration.classList.remove("hidden");
  } else {
    errorRegistration.classList.add("hidden");
    const newUser = {
      userName: name,
      password: password,
    };
    try {
      const res = await fetch("http://localhost:5000/registration", {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify(newUser),
      });

      const data = await res.json();
    } catch (err) {
      console.log("Error while sending data to the server: ", err);
    } finally {
      window.location.href = "../login/login.html";
    }
  }
};
//======Redirect to login if user have accout from index page==========
const redirectToLogin = () => {
  window.location.href = "../login/login.html";
};
