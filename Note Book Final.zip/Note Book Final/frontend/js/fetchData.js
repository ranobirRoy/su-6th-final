//=============checking frontend data for user login========
const fetchLoggedUserData = async (loggedInUserId) => {
  let loggedUserData = [];

  try {
    const loggedInUserId = JSON.parse(
      //localstorage json string data to javasting object (array)
      localStorage.getItem("loggedInUser")
    ).userId;
    const res = await fetch(
      `http://localhost:5000/getLoggedUserData/${loggedInUserId}`
    );
    loggedUserData = await res.json();
    showAllNotebookData(loggedUserData);
    showNotebookUserData(loggedUserData);
  } catch (err) {
    console.log("Error fetching comments from the server:", err);
  } finally {
    return loggedUserData;
  }
};
fetchLoggedUserData();
//========================showing data in Dashboard=============================
const showAllNotebookData = (allNotebooks) => {
  const notebookContainer = document.getElementById("notebook-wraper");
  notebookContainer.innerHTML = "";

  allNotebooks.forEach((notebookData) => {
    const notebookDiv = document.createElement("div");
    notebookDiv.classList.add("notebook");
    notebookDiv.innerHTML = `
    <div class="notebook-text">
              <textarea
                name="notebookText"
                id="notebookText${notebookData.noteId}"
                class="notebook-text block-edit"
              >${notebookData.noteText}</textarea>
            </div>
            <div class="options">
              <button id="enableEdit${notebookData.noteId}" onclick="enableEdit('${notebookData.noteId}')">
                <span><i class="fa-solid fa-pen-to-square"></i></span>
                Edit
              </button>
              <button id="deleteNote" onclick="deleteNote(${notebookData.noteId})">
                <span><i class="fa-solid fa-trash"></i></span>
                Delete
              </button>
              <button id="editNote${notebookData.noteId}" onclick="editNote('${notebookData.noteId}')" class="hidden">
                <span><i class="fa-solid fa-floppy-disk"></i></span>
                Save
              </button>
              <button id="undoEdit${notebookData.noteId}"
              onclick="undoEdit('${notebookData.noteId}')" class="hidden">
                <span><i class="fa-solid fa-rotate-left"></i></span>
                Cancel Edit
              </button>
            </div>
    `;

    notebookContainer.appendChild(notebookDiv);
  });
};
const showNotebookUserData = (notebookUserData) => {
  const notebookUserContainer = document.getElementById("name");
  notebookUserContainer.innerHTML = "";
  notebookUserData.forEach((userData) => {
    notebookUserContainer.innerHTML = `<h3>${userData.userName}</h3>`;
  });
};
//========================adding note=============================================
const addNote = async () => {
  const loggedInUserId = JSON.parse(
    localStorage.getItem("loggedInUser")
  ).userId;
  const newNotebook = document.getElementById("newNotebook");
  const newNotebookData = newNotebook.value;
  const addNoteObject = {
    noteUserId: loggedInUserId,
    noteText: newNotebookData,
  };
  try {
    const res = await fetch("http://localhost:5000/addNote", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(addNoteObject),
    });

    const data = await res.json();
  } catch (err) {
    console.log("Error while sending data to the server: ", err);
  } finally {
    location.reload();
  }
};
//=======================delete note==============================

const deleteNote = async (noteId) => {
  try {
    const loggedInUserId = JSON.parse(
      localStorage.getItem("loggedInUser")
    ).userId;

    const res = await fetch(
      `http://localhost:5000/deleteNote/${loggedInUserId}/${noteId}`,
      { method: "POST" }
    );
  } catch (err) {
    console.log("Error while deleting note:", err);
  } finally {
    location.reload();
  }
};

//=========================Edit note===========================
const editNote = async (noteId, newText) => {
  try {
    const notebookText = document.getElementById(`notebookText${noteId}`);
    const updateText = notebookText.value;

    const loggedInUserId = JSON.parse(
      localStorage.getItem("loggedInUser")
    ).userId;
    const updateData = {
      updateText: updateText,
    };
    const res = await fetch(
      `http://localhost:5000/editNote/${loggedInUserId}/${noteId}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updateData),
      }
    );

    const result = await res.json();
    return result;
  } catch (err) {
    console.error("Error while updating note:", err);
    throw err;
  } finally {
    // editNoteButton.classList.add("murder");
    location.reload();
  }
};
//=======================Log out system=======================
const logout = () => {
  localStorage.clear();
  window.location.href = "../login/login.html";
};
