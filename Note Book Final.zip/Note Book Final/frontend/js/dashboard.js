const notebookAdd = () => {
  const newNotebookWraper = document.getElementById("newNotebookWraper");
  newNotebookWraper.classList.add("unhide");
};
const notebookCancel = () => {
  const newNotebookWraper = document.getElementById("newNotebookWraper");
  newNotebookWraper.classList.remove("unhide");
};
const enableEdit = (noteId) => {
  const editNoteButton = document.getElementById(`editNote${noteId}`);
  const undoEditButton = document.getElementById(`undoEdit${noteId}`);
  const notebookText = document.getElementById(`notebookText${noteId}`);
  editNoteButton.classList.remove("hidden");
  undoEditButton.classList.remove("hidden");
  notebookText.classList.remove("block-edit");
  notebookText.focus();
};
const undoEdit = (noteId) => {
  const editNoteButton = document.getElementById(`editNote${noteId}`);
  const undoEditButton = document.getElementById(`undoEdit${noteId}`);
  const notebookText = document.getElementById(`notebookText${noteId}`);
  editNoteButton.classList.add("hidden");
  undoEditButton.classList.add("hidden");
  notebookText.classList.add("block-edit");
  location.reload();
};
