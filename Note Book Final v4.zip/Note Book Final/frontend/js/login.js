const handleLogin = async () => {
  const inputId = document.getElementById("inputId");
  const inputPassword = document.getElementById("inputPassword");

  const userId = inputId.value;
  const password = inputPassword.value;

  const user = {
    userId: userId,
    password: password,
  };
  fetchDatabaseDataForLogin();
  const loggedUserInfo = await fetchDatabaseDataForLogin(user);
  if (loggedUserInfo.length === 0) {
    userNotFound.classList.remove("hidden");
  } else {
    userNotFound.classList.add("hidden");
    localStorage.setItem("loggedInUser", JSON.stringify(loggedUserInfo[0]));
    window.location.href = "../dashboard/dashboard.html";
  }
};
//===================fetching data from userver to check user here (handleLogin)=========================
const fetchDatabaseDataForLogin = async (user) => {
  let data;
  try {
    const res = await fetch("http://localhost:5000/databaseDataForLogin", {
      method: "POST",
      headers: {
        "content-type": "application/json",
      },
      body: JSON.stringify(user),
    });
    data = await res.json();
  } catch (err) {
    console.error("Error from fetchDatabaseDataForLogin:", err);
  } finally {
    return data;
  }
};
//======Redirect to registration if user don't have accout from index page==========
const redirectToRegistration = () => {
  window.location.href = "../registration/registration.html";
};
