const express = require("express");
const mysql = require("mysql");
const cors = require("cors");
const port = 5000;
const app = express();
//====================middlewares==============
app.use(cors());
app.use(express.json());

// ============connection with mysql===============
let db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "notebook",
});
//==================================================
db.connect((err) => {
  if (err) {
    console.log("Something went wrong while connecting to the database: ", err);
    throw err;
  } else {
    console.log("MySQL server connected...");
  }
});
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
//==========================Registration system=============================
app.post("/registration", (req, res) => {
  const { userName, password } = req.body;
  let sqlForRegistration = `INSERT INTO users (userId, userName, password) VALUES (NULL, ?, ?)`;

  let query = db.query(
    sqlForRegistration,
    [userName, password],
    (err, result) => {
      if (err) {
        console.log("Error while adding a new post in the database:", err);
        throw err;
      } else {
        res.send(result);
      }
    }
  );
});
//==========================creating api to send data database to fetchData for check user info=============================
app.post("/databaseDataForLogin", (req, res) => {
  const { userId, password } = req.body;

  const getUserInfosql = `SELECT userId, userName FROM users WHERE users.userId = ? AND users.password = ?`;

  let query = db.query(getUserInfosql, [userId, password], (err, result) => {
    if (err) {
      console.log("Error getting user info from server:", err);
      throw err;
    } else {
      res.send(result);
    }
  });
});
//=======================getting logged user data from database using loggedUserId==========================================================
app.post("/getLoggedUserData/:loggedInUserId", (req, res) => {
  let id = req.params.loggedInUserId;

  let sqlForGetLoggedUserData = `SELECT users.userId, users.userName,notedata.noteId, notedata.noteText 
FROM users 
INNER JOIN notedata ON users.userId = notedata.noteUserId WHERE users.userId = ? ORDER BY notedata.noteId DESC`;

  let query = db.query(sqlForGetLoggedUserData, [id], (err, result) => {
    if (err) {
      console.log("Error fetching comments from the database:", err);
      throw err;
    } else {
      res.send(result);
    }
  });
});
//=================================adding data to database using loggedUserId==========================================
app.post("/addNote", (req, res) => {
  const { noteUserId, noteText } = req.body;
  let sqlForAddNote = `INSERT INTO notedata (noteId, noteUserId, noteText) VALUES (NULL, ?, ?)`;

  let query = db.query(sqlForAddNote, [noteUserId, noteText], (err, result) => {
    if (err) {
      console.log("Error while adding a new post in the database:", err);
      throw err;
    } else {
      res.send(result);
    }
  });
});
//====================delete note data from database=======================
app.post("/deleteNote/:loggedInUserId/:noteId", (req, res) => {
  let loggedInUserId = req.params.loggedInUserId;
  let noteId = req.params.noteId;

  let sqlForDeleteNote = `DELETE FROM notedata WHERE noteUserId = ? AND noteId = ?`;

  let query = db.query(
    sqlForDeleteNote,
    [loggedInUserId, noteId],
    (err, result) => {
      if (err) {
        console.log("Error fetching comments from the database:", err);
        throw err;
      } else {
        res.send(result);
      }
    }
  );
});
//=======================Edit notebook=======================
app.post("/editNote/:loggedInUserId/:noteId", (req, res) => {
  const { updateText } = req.body;
  let loggedInUserId = req.params.loggedInUserId;
  let noteId = req.params.noteId;

  let sqlForEditNote = `UPDATE notedata SET noteText= ? WHERE noteUserId = ? AND noteId = ? `;

  let query = db.query(
    sqlForEditNote,
    [updateText, loggedInUserId, noteId],
    (err, result) => {
      if (err) {
        console.log("Error fetching comments from the database:", err);
        throw err;
      } else {
        res.send(result);
      }
    }
  );
});
